<?php
// +------------------------------------------------------------------------+
// | @author        : Michael Arawole (Logad Networks)
// | @author_url    : https://www.logad.net
// | @author_email  : michael@logad.net
// | @date          : 24 Dec, 2022 03:00PM
// +------------------------------------------------------------------------+

// +----------------------------+
// | Configuration file
// +----------------------------+

// Database host
$dbHost = 'localhost';

// Database username
$dbUser = 'root';

// Database password
$dbPass = '';

// Database Name
$dbName = 'worker_shifts';